﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DBRadio.Migrations
{
    public partial class _1112 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
